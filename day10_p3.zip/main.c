/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>


int main()
{
    char another;
    int num,square;
    
    for(;;)
    {
    printf("Enter a number");
    scanf("%d",&num);//read the number from user
    
    //TAKING  OF SQUARE OF THE NUMBER
    square=num*num;
    printf("Calculate the square of %d is %d\n",num,square);
     
     printf("Want to enter the anothernumber(y/n)?  ");
     scanf(" %c",&another);//READ THE USER'S DECISION TO continue
     
     if(another == 'n')
     {
         break;//EXIT THE LOP IF USER ENTERS 'N'
         }
        else if(another !='y')
        {
            printf("Invalid input.Plese enter 'y' or 'n'.\n");
            continue;//skip the rest of the loop and start the next;
        }
        
        //CLEAR THE INPUT BUFFER TO HANDLE EXTRA CHARACTERS
        while(getchar()!='\n');
    }
     return 0;   
            
            
}
     
     
  
