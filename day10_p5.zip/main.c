/******************************************************************************
 
Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*GENERATE ALL THE POSSIBLE COMBINATION OF 123*/
#include <stdio.h>

int main()
{
  int i=1,j=1,k=1;
  for(int i=1;i<=3;i++)
  {
      for(int j=1;j<=3;j++)
      {
          for(k=1;k<=3;k++)
          printf("%d%d%d\n",i,j,k);
      }
  }

    return 0;
}
